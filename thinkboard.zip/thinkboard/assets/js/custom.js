(function($) {
	"use strict";

	// Ready Function Start >>
	$(document).ready(function(){

		// Revolution Slider
		$('.tp-banner').show().revolution({
			dottedOverlay:"none",
			delay:16000,
			startwidth:1170,
			startheight:700,
			hideThumbs:200,
			thumbWidth:100,
			thumbHeight:50,
			thumbAmount:5,
			navigationType:"none",
			navigationArrows:"solo",
			navigationStyle:"preview4",
			touchenabled:"on",
			onHoverStop:"on",
			swipe_velocity: 0.7,
			swipe_min_touches: 1,
			swipe_max_touches: 1,
			drag_block_vertical: false,
			parallax:"mouse",
			parallaxBgFreeze:"on",
			parallaxLevels:[7,4,3,2,5,4,3,2,1,0],
			keyboardNavigation:"off",
			navigationHAlign:"center",
			navigationVAlign:"bottom",
			navigationHOffset:0,
			navigationVOffset:20,
			soloArrowLeftHalign:"left",
			soloArrowLeftValign:"center",
			soloArrowLeftHOffset:20,
			soloArrowLeftVOffset:0,
			soloArrowRightHalign:"right",
			soloArrowRightValign:"center",
			soloArrowRightHOffset:20,
			soloArrowRightVOffset:0,		
			shadow:0,
			fullWidth:"off",
			fullScreen:"on",
			spinner:"spinner4",
			stopLoop:"off",
			stopAfterLoops:-1,
			stopAtSlide:-1,
			shuffle:"off",
			autoHeight:"off",						
			forceFullWidth:"off",										
			hideThumbsOnMobile:"off",
			hideNavDelayOnMobile:1500,						
			hideBulletsOnMobile:"off",
			hideArrowsOnMobile:"off",
			hideThumbsUnderResolution:0,
			hideSliderAtLimit:0,
			hideCaptionAtLimit:0,
			hideAllCaptionAtLilmit:0,
			startWithSlide:0,
			fullScreenOffsetContainer: ".header"	

		});

		// hide .back-top first
		$(".back-top").hide();

		// mixItUp
	    $('#Container').mixItUp(); 

	    // CounterUp
	    $('.counter').counterUp({
		    delay: 10,
		    time: 1000
		});

		
		// Porfolio Grid
	    if( $(".grid").length> 0 ) {
			$('.grid').masonry({
			  // options
			  itemSelector: '.grid-item',
			});
		}

		// Popup Vidoe
		if( $(".mymodal").length> 0 ) {
			$(".mymodal").magnificPopup({
				  type: "iframe",
				  mainClass: "mfp-no-margins"
			});
		}

	}); // Ready

	// scroll body to 0px on click
	$(document).on( 'click', '.back-top a', function () {
		$('body,html').animate({
			scrollTop: 0
		}, 800);
		return false;
	});

	$(window).scroll(function () {
		if ($(this).scrollTop() > 100) {
			$('.back-top').fadeIn();
		} else {
			$('.back-top').fadeOut();
		}
	});

	//Preloader
	$(window).load(function() {
		$('#status').fadeOut();
		$('#preloader').delay(350).fadeOut('slow');
		$('body').delay(350).css({'overflow':'visible'});
	});

})(jQuery);