$(document).ready(function() {
	// Location detail area load map
	function initialize() {
		var myCenter = new google.maps.LatLng(40.6700, -73.9400);
		var mapProp = {
			center : myCenter,
			zoom : 11,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			scrollwheel: false,
			styles: [{"stylers":[{"hue":"#ff1a00"},{"invert_lightness":true},{"saturation":-100},{"lightness":33},{"gamma":0.5}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#2D333C"}]}]
		};
		var map = new google.maps.Map(document.getElementById("googleMap"), mapProp);
		var marker = new google.maps.Marker({
			position : myCenter,
			icon : 'assets/images/map-marker.png'
		});
		marker.setMap(map);
	}
	
	if(document.getElementById('googleMap') != null ) {
		google.maps.event.addDomListener(window, 'load', initialize);
	}
		
});